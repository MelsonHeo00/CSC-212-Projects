#include <assert.h>    // Provides assert function
#include <iomanip>   // Provides setw
#include <iostream>  // Provides cin, cout
#include <math.h>      // Provides log2
#include "pqueue2.h"
using namespace std;

PriorityQueue::PriorityQueue()
{
    many_items = 0;
}

void PriorityQueue::insert(const Item& entry, unsigned int priority)
{
    heap[many_items].data = entry;
    heap[many_items].priority = priority;
    size_t current = many_items;
    while (current > 0)
    {
        if (heap[current].priority > heap[parent_index(current)].priority)
            swap_with_parent(current);
        current = parent_index(current);
    }
    many_items++;
}

PriorityQueue::Item PriorityQueue::get_front()
{
    assert(size() > 0);
    Item front;
    front = heap[0].data;
    size_t last_index = many_items - 1;
    heap[0].data = heap[last_index].data;
    heap[0].priority = heap[last_index].priority;
    many_items--;
    size_t current = 0;
    if (size() > 1)
    {
        while (!is_leaf(current))
        {
            if (heap[current].priority < heap[big_child_index(current)].priority)
            {
                size_t temp = big_child_index(current);
                swap_with_parent(big_child_index(current));
                current = temp;
            }
            else {
                break;
            }
        }
    }
    return front;
}

bool PriorityQueue::is_leaf(size_t i) const
{
    assert(i < many_items);
    size_t left_child = 2 * i + 1;
    size_t right_child = 2 * i + 2;
    return ((left_child >= many_items) && (right_child >= many_items));
}

size_t PriorityQueue::parent_index(size_t i) const
{
    // assert((i>0) && (i<many_items)); // (This line gives me an error during the test file but it should work when this line is using the interactive test)
    return (i - 1) / 2;
}

unsigned int PriorityQueue::parent_priority(size_t i) const
{
    assert((i>0) && (i< many_items));
    return heap[parent_index(i)].priority;
}

size_t PriorityQueue::big_child_index(size_t i) const
{
    assert(!is_leaf(i));
    if (heap[(2 * i) + 1].priority > heap[(2 * i) + 2].priority)
    {
        return (2 * i) + 1;
    }
    else
    {
        return (2 * i) + 2;
    }
}

unsigned int PriorityQueue::big_child_priority(size_t i) const
{
    assert(!is_leaf(i));
    return heap[big_child_index(i)].priority;
}

void PriorityQueue::swap_with_parent(size_t i)
{
    // assert((i>0) && (i< many_items)); // (This line gives me an error during the test file but it should work when this line is using the interactive test)
    OneItemInfo temp;
    temp = heap[parent_index(i)];
    heap[parent_index(i)] = heap[i];
    heap[i] = temp;
}

void PriorityQueue::print_tree(const char message[], size_t i) const
{
    const char NO_MESSAGE[] = "";
    size_t depth;
    if (message[0] != '\0')
    {
        cout << message << endl;
    }
    if (i > many_items)
    {
        cout << "NO NODES" << endl;
    }
    else
    {
        depth = int(log(double(i + 1)) / log(2.0));
        cout << setw(depth * 4) << "";
        cout << heap[i].data;
        cout << " (priority " << heap[i].priority << ")" << endl;
        if (2 * i + 1 < many_items)
        {
            print_tree(NO_MESSAGE, 2 * i + 1);
        }
        if (2 * i + 2 < many_items)
        {
            print_tree(NO_MESSAGE, 2 * i + 2);
        }
    }
}