#include <cstdlib>
#include <math.h>
#include <iomanip> 
#include <iostream>
#include <cassert>
#include <string.h>
#include "stats.h"
using namespace std;
using namespace main_savitch_2C;

//Default Constructor
statistician::statistician() {
    count = 0;
    total = 0.0;
    tinyest = 0.0;
    largest = 0.0;
}

void statistician::next(double r)  //The next function
{
    if (count <= 0)
    {
        count = 1;
        total = r;
        tinyest = r;
        largest = r;
        return;
    }
    else
    {
        count += 1;
        total += r;
        if (r < tinyest)
            tinyest = r;
        if (r > largest)
            largest = r;
    }
    mean();
}

void statistician::reset() { //Resets an entire stats
    count = 0;
    total = 0.0;
    tinyest = 0.0;
    largest = 0.0;
}

int statistician::length() const //The amount of input of inputted values
{
    return count;   
}

double statistician::sum() const //The total of the input values
{
    return total;
}

double statistician::mean() const //The mean of the input values
{
    return total / count;
}

double statistician::minimum() const //The minimum of the input values
{
    return tinyest;
}

double statistician::maximum() const //The maximum of the input values
{
    return largest;
}

statistician main_savitch_2C::operator+(const statistician& s1, const statistician& s2)
{
    if (s1.length() == 0) {
        return statistician(s2);
    }
    else if (s2.length() == 0) {
        return statistician(s1);
    }
    statistician s = statistician();
    s.count = s1.count + s2.count;
    s.total = s1.total + s2.total;
        if (s1.tinyest < s2.tinyest || s1.tinyest == s2.tinyest) {
            s.tinyest = s1.tinyest;
        }
        else {
            s.tinyest = s2.tinyest;
        }
    if (s1.largest < s2.largest || s1.largest == s2.largest) {
        s.largest = s2.largest;
    }
    else {
        s.largest = s1.largest;
    }
    return s;
}

statistician main_savitch_2C::operator*(double scale, const statistician& s)
{
    if (s.length() == 0) return statistician();
    statistician s3 = statistician();
    s3.count = s.count;
    s3.total = s.total * scale;
    if (scale > 0) {
        s3.largest = s.largest * scale;
        s3.tinyest = s.tinyest * scale;
    }
    else {
        s3.largest = s.tinyest * scale;
        s3.tinyest = s.largest * scale;
    }
    return s3;
}

bool main_savitch_2C::operator==(const statistician& s1, const statistician& s2)
{
    if ((s1.length() == 0) && (s2.length() == 0)) return true;
    if (!(s1.length() == s2.length())) return false;
    else if (!(s1.sum() == s2.sum())) return false;
    else if (!(s1.minimum() == s2.minimum())) return false;
    else if (!(s1.maximum() == s2.maximum())) return false;
    else if (!(s1.mean() == s2.mean())) return false;
    return true;
}