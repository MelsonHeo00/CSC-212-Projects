#include <cstdlib>	// Provides EXIT_SUCCESS and size_t
#include "newnode.h"   // With node::valuetype defined as double
#include <cassert>

namespace main_savitch_5
{
	size_t list_length(const node* head_ptr) //This notation is O(n)
	{
		const node* cursor;
		size_t answer;
		answer = 0;
		for (cursor = head_ptr; cursor != NULL; cursor = cursor->link())
			++answer;
		return answer;
	}

	void list_head_insert(node*& head_ptr, const node::value_type& entry) //This notation is O(n)
	{
		head_ptr = new node(entry, head_ptr);
	}

	void list_insert(node* previous_ptr, const node::value_type& entry) //This notation is O(n)
	{
		node* insert_ptr;
		insert_ptr = new node(entry, previous_ptr->link());
		previous_ptr->set_link(insert_ptr);
	}

	node* list_search(node* head_ptr, const node::value_type& target) //This notation is O(n)
	{
		node* cursor;
		for (cursor = head_ptr; cursor != NULL; cursor = cursor->link())
			if (target == cursor->data())
				return cursor;
		return NULL;
	}

	const node* list_search(const node* head_ptr, const node::value_type& target) //This notation is O(n)
	{
		const node* cursor;
		for (cursor = head_ptr; cursor != NULL; cursor = cursor->link())
			if (target == cursor->data())
				return cursor;
		return NULL;
	}

	node* list_locate(node* head_ptr, size_t position) //This notation is O(n)
	{
		node* cursor;
		size_t i;
		assert(0 <= position);
		cursor = head_ptr;
		for (i = 1; (i < position) && (cursor != NULL); i++)
			cursor = cursor->link();
		return cursor;
	}

	const node* list_locate(const node* head_ptr, size_t position) //This notation is O(n)
	{
		const node* cursor;
		size_t i;
		assert(0 <= position);
		cursor = head_ptr;
		for (i = 1; (i < position) && (cursor != NULL); i++)
			cursor = cursor->link();
		return cursor;
	}

	void list_head_remove(node*& head_ptr) //This notation is O(n)
	{
		node* remove_ptr;
		remove_ptr = head_ptr;
		head_ptr = head_ptr->link();
		delete remove_ptr;
	}

	void list_remove(node* previous_ptr) //This notation is O(n)
	{
		node* remove_ptr;
		remove_ptr = previous_ptr->link();
		previous_ptr->set_link(remove_ptr->link());
		delete remove_ptr;
	}

	void list_clear(node*& head_ptr) //This notation is O(n)
	{
		while (head_ptr != NULL)
			list_head_remove(head_ptr);
	}

	void list_copy(const node* source_ptr, node*& head_ptr, node*& tail_ptr) //This notation is O(n)
	{
		head_ptr = NULL;
		tail_ptr = NULL;
		if (source_ptr == NULL)
			return;
		list_head_insert(head_ptr, source_ptr->data());
		tail_ptr = head_ptr;
		source_ptr = source_ptr->link();
		while (source_ptr != NULL)
		{
			list_insert(tail_ptr, source_ptr->data());
			tail_ptr = tail_ptr->link();
			source_ptr = source_ptr->link();
		}
	}

	std::size_t list_occurrences(const node* head_ptr, const node::value_type& target) //This notation is O(n)
	{
		size_t count = 0; //declares the variable to record the inputs
		for (head_ptr = list_search(head_ptr, target);
			head_ptr != NULL; //assure that head_ptr is not equal to NULL
			head_ptr = list_search(head_ptr->link(), target))
			count++; //+1 answer for every number that it came across
		return count;
	}

	void list_tail_attach(node*& head_ptr, const node::value_type& entry) //This notation is O(n)
	{
		node *tail_ptr; //declaring a tail pointer
		if (head_ptr == NULL) //For any of the empty linked lists
		{
			head_ptr = new node(entry, NULL);
		}
		else //For any of the nonempty linked lists
		{
			tail_ptr = list_locate(head_ptr, list_length(head_ptr));
			list_insert(tail_ptr, entry);
		}
	}
	
	void list_tail_remove(node*& head_ptr) //This notation is O(n)
	{
		size_t x = list_length(head_ptr);
		if (x == 1) //If there is only one node, then it removes the one node within the list
		{
			list_head_remove(head_ptr);
		}
		else //Deletes a node
		{
			node* temp = list_locate(head_ptr, x -1);
			list_remove(temp);
		}
	}

	node* list_copy_front(const node* source_ptr, std::size_t n) //This notation is O(n)
	{
		node* list = NULL; //declaring a pointer that is NULL
		if (list_length(source_ptr) < n) {
			n = list_length(source_ptr);
		}
		for (size_t i = 1; i <= n; i++) {
			list_tail_attach(list, source_ptr->data());
			source_ptr = source_ptr->link();
		}
		return list;
	}
}